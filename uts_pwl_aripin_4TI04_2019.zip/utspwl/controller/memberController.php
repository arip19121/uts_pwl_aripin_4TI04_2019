<?php

session_start();

require_once '../koneksi.php';
require_once '../model/Member.php';
$username = $_POST['username'];
$password = $_POST['password'];


$data = [
    $username,
    $password,
];

$obj = new Member();
$result = $obj->check_login($data);
if (!empty($result)) {
    $_SESSION['MEMBER'] = $result;
    header('Location:http://localhost/utspwl/index.php?hal=dataPegawai');
} else {
    header('Location:http://localhost/utspwl/index.php?hal=gagalLogin');
}
