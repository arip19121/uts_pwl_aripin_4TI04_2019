<?php

require_once '../koneksi.php';
require_once '../model/Pegawai.php';

$nip = $_POST['nip'];
$nama = $_POST['nama'];
$email = $_POST['email'];
$agama = $_POST['agama'];
$divisi = $_POST['divisi'];
$foto = $_POST['foto'];
$event = $_POST['proses'];
$data = [
    $nip,
    $nama,
    $email,
    $agama,
    $divisi,
    $foto,
];
$obj = new Pegawai();
switch ($event) {
    case 'simpan':
        $obj->insertPegawai($data);
        break;
    case 'edit':
        $data[] = $_POST['id'];
        $obj->editPegawai($data);
        break;
    case 'hapus':
        $id[] = $_POST['id'];
        $obj->deletePegawai($id);
        break;
    default:
        header('Location:http://localhost/utspwl/index.php?hal=dataPegawai');
        break;
}

header('Location:http://localhost/utspwl/index.php?hal=dataPegawai');
