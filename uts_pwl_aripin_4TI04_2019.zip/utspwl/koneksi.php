<?php

$server = 'mysql:dbname=dbpegawai;host=localhost';
$user = 'root';
$password = '';

try {
    $db = new PDO($server, $user, $password);
	$db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY,TRUE);

} catch (PDOException $e) {
    echo 'Error Connection '.$e->getMessage();
}
