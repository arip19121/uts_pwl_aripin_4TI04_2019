<div class="row mt-3">
	<div class="col-md-9">
	    <div class="jumbotron">
	      <h1 class="display-4">Aplikasi UTS PWL</h1>
	      <p class="lead">Ini adalah tugas UTS membuat aplikasi web. Dijadikan sebagai syarat kelulusan untuk tahap selnajutnya.</p>
	      <hr class="my-4">
	      <p>Dibuat oleh Aripin 0110219121 4TI04 Weekend 2019.</p>
	      <a class="btn btn-danger btn-lg" href="#" role="button">Pelajari lebih lanjut</a>
	    </div>
  	</div>
