<?php
  require_once '../../htdocs/utspwl/model/Pegawai.php';
  $obj = new Pegawai();
  $divisi = $obj->getDivisi();
?>

<div class="row mt-3">
  <div class="col-md-9">
    <form action="../../utspwl/controller/pegawaiController.php" method="POST">
      <div class="form-group">
          <label for="exampleInputEmail1">NIP</label>
          <input type="number" class="form-control" id="nip" name="nip" value="">
      </div>
      <div class="form-group">
          <label for="exampleInputPassword1">Nama</label>
          <input type="text" class="form-control" id="nama" name="nama" value="">
      </div>
      <div class="form-group">
          <label for="exampleInputPassword1">Email</label>
          <input type="email" class="form-control" name="email" id="email" value="">
      </div>
      <div class="form-group">
      <label for="exampleInputPassword1">Agama</label>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="agama" id="exampleRadios1" value="Islam" checked>
          <label class="form-check-label" for="exampleRadios1">
            Islam
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="agama" id="exampleRadios2" value="Kristen Protestan">
          <label class="form-check-label" for="exampleRadios2">
            Kristen Protestan
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="agama" id="exampleRadios3" value="Kristen Katholik">
          <label class="form-check-label" for="exampleRadios3">
            Kristen Katholik
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="agama" id="exampleRadios4" value="Hindu">
          <label class="form-check-label" for="exampleRadios4">
            Hindu
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="agama" id="exampleRadios5" value="Budha">
          <label class="form-check-label" for="exampleRadios5">
            Budha
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="agama" id="exampleRadios6" value="Konghucu">
          <label class="form-check-label" for="exampleRadios6">
            Konghucu
          </label>
        </div>
      </div>
      <div class="form-group">
        <label for="divisi">Pilih Divisi</label>
        <select class="form-control" name="divisi" id="divisi">
          <option selected>-- Pilih Divisi --</option>
          <?php
            foreach($divisi as $val){
              ?>
                <option value="<?= $val['id'] ?>"> <?= $val['nama'] ?> </option>
              <?php
            }
          ?>
        </select>
      </div>
      <div class="form-group">
          <label for="exampleInputPassword1">Foto</label>
          <input type="text" class="form-control" id="nama" name="foto" value="">
      </div>
      <button type="submit" name="proses" value="simpan" class="btn btn-danger">Submit</button>
    </form>
  </div>
