
	<div class="col-md-3">
   <div class="card" style="width: 100%;">
      <div style="font-family:" class="card-header bg-primary" style="color: white">
        Tentang kami
      </div>
      <ul class="list-group list-group-flush">
        <li class="list-group-item">PT Mulia Bersama Teknologi</li>
        <li class="list-group-item">Jl. Masjid al-mubarokah No. 9 Ciputat, Tangerang selatan</li>
        <li class="list-group-item">085798692347</li>
      </ul>
    </div>
  </div>
</div>
