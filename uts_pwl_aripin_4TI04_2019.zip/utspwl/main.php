<?php

	if (empty($_REQUEST['hal'])) {
		include_once 'view/content/content.php';
	} else {
		$hal = $_REQUEST['hal'];
		include_once 'view/content/'.$hal.'.php';
	}

?>
