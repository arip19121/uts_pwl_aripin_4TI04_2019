<?php

class Member
{
    private $connection;
    public function __construct()
    {
        global $db;
        $this->connection = $db;
    }

    public function check_login($data) {
        $query = 'select * from dbpegawai.member where username = "'.$data[0].'" and password=md5("'.$data[1].'")';
        $get = $this->connection->prepare($query);
        $get->execute();
		    $result = $get->fetch();
        if ($result) {
            return $result;
        } else {
            return NULL;
        }

    }
}
