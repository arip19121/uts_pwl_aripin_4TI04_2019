<?php
session_start();
require_once 'koneksi.php';

include_once 'view/header/header.php';
include_once 'view/menu/menu.php';
include_once 'main.php';
include_once 'view/sidebar/sidebar.php';
include_once 'view/footer/footer.php';
