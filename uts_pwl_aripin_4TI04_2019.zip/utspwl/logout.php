<?php
session_start();
unset($_SESSION['MEMBER']);

header('Location:http://localhost/utspwl/index.php');
